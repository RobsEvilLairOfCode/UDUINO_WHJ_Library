#include "uduino_config.h"
#include "gpio.h"

/*
led_init();

Inputs:
    None
Returns:
    None

Initiates all LED pins to outputs. Call this function before using the LEDs.
*/
void led_init(void);

/*
led_set();

Inputs:
    pos - an integer value from 0 to 7 indicating which led you want to set
    value - a integer value which is either 0 or 1. 0 turns the LED off, 1 turns the LED on 
Returns:
    None

Controls individual leds, turning them on or off.
*/
void led_set(char, char);