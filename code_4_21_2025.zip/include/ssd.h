#include "gpio.h"
#include "timer.h"

void ssd_init();

void ssd_set_a(char val);
void ssd_set_b(char val);
void ssd_set_c(char val);
void ssd_set_d(char val);
void ssd_set_e(char val);
void ssd_set_f(char val);
void ssd_set_g(char val);
void ssd_set_dp(char val);
void ssd_set_anode(char anode);