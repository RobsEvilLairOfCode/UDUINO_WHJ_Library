#include "uduino_config.h"

TIM_HandleTypeDef htim16;

TIM_HandleTypeDef htim17;

TIM_HandleTypeDef htim7;

void timer_16_init(int prescaler, int period);

void timer_17_init(int prescaler, int period);

void timer_16_start();

void timer_17_start();