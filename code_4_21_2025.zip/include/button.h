#include "uduino_config.h"
#include "gpio.h"

void button_init(void);

char button_read(char);