#include "timer.h"

void timer_16_init(int prescaler, int period){
    htim16.Instance = TIM16;
    htim16.Init.Prescaler = prescaler;
    htim16.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim16.Init.Period = period;
    htim16.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim16.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    /* TIM16 interrupt Init */
    HAL_TIM_Base_Init(&htim16);
}

void timer_17_init(int prescaler, int period){
    htim17.Instance = TIM17;
    htim17.Init.Prescaler = prescaler;
    htim17.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim17.Init.Period = period;
    htim17.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim17.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    /* TIM16 interrupt Init */
    HAL_TIM_Base_Init(&htim17);
}

void timer_16_start(){
    HAL_TIM_Base_Start_IT(&htim16);
}

void timer_17_start(){
    HAL_TIM_Base_Start_IT(&htim17);
}

//------------------------------------------------Do not directly call functions below-------------------------------------

void TIM16_IRQHandler(void)
{
  /* USER CODE BEGIN TIM16_IRQn 0 */

  /* USER CODE END TIM16_IRQn 0 */
  HAL_TIM_IRQHandler(&htim16);
  /* USER CODE BEGIN TIM16_IRQn 1 */

  /* USER CODE END TIM16_IRQn 1 */
}

void TIM17_IRQHandler(void)
{
  /* USER CODE BEGIN TIM16_IRQn 0 */

  /* USER CODE END TIM16_IRQn 0 */
  HAL_TIM_IRQHandler(&htim17);
  /* USER CODE BEGIN TIM16_IRQn 1 */

  /* USER CODE END TIM16_IRQn 1 */
}

void TIM7_IRQHandler(void)
{
  /* USER CODE BEGIN TIM16_IRQn 0 */

  /* USER CODE END TIM16_IRQn 0 */
  HAL_TIM_IRQHandler(&htim7);
  /* USER CODE BEGIN TIM16_IRQn 1 */

  /* USER CODE END TIM16_IRQn 1 */
}


void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* tim_baseHandle)
{
  if(tim_baseHandle->Instance==TIM16)
  {
    /* TIM16 clock enable */
    __HAL_RCC_TIM16_CLK_ENABLE();

    /* TIM16 interrupt Init */
    HAL_NVIC_SetPriority(TIM16_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(TIM16_IRQn);
  }
  if(tim_baseHandle->Instance==TIM17)
  {
    /* TIM16 clock enable */
    __HAL_RCC_TIM17_CLK_ENABLE();

    /* TIM16 interrupt Init */
    HAL_NVIC_SetPriority(TIM17_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(TIM17_IRQn);
  }
  if(tim_baseHandle->Instance==TIM7)
  {
    /* TIM16 clock enable */
    __HAL_RCC_TIM7_CLK_ENABLE();

    /* TIM16 interrupt Init */
    HAL_NVIC_SetPriority(TIM7_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(TIM7_IRQn);
  }
}

