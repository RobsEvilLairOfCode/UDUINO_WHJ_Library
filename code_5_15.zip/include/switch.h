#include "uduino_config.h"
#include "gpio.h"

void switch_init(void);

char switch_read(char);