/* USER CODE BEGIN Header */
#include "main.h"
#include <stdio.h>
#include "string.h"



#define FALSE 0
#define TRUE 1
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef hlpuart1;

RTC_HandleTypeDef hrtc;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim16;

TIM_HandleTypeDef htim17;

PCD_HandleTypeDef hpcd_USB_FS;

/* USER CODE BEGIN PV */
/* USER CODE END PV */



/* Private function prototypes -----------------------------------------------*/

void setLED(char pos, char value);
void setSSD(char pos, char digit);
void setRow(char row);
char readKey(char key);
char readKeyDebounced(char key);
void LCD_Clear();
void LCD_Write(const uint8_t addr, const char *Row, const int count);
void LCD_Init();

/* USER CODE BEGIN PFP */
const int LCD_ROW_0_ADDR = 0x00;
const int LCD_ROW_1_ADDR = 0x40;
char LCD_BUFFER[32];
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */

unsigned char led_test_counter = 0;

unsigned char ssd_digits[] = {10,10,10,10};
unsigned char ssd_digits_pos = 0;

unsigned char lcd_test_flag = TRUE;




//LAB RELATED
unsigned char buzzer_on = FALSE;

unsigned char alarm_on = FALSE;

unsigned char alarm_counter = 10;

//1 = set time, 2 = set alarm, 3 = Display time, 4 = Alarming
unsigned char mode = 1;

unsigned char hour = 0;
unsigned char min = 0;

unsigned char alarm_hour = 12;
unsigned char alarm_min = 00;

unsigned char time_digits[] = {1,2,0,0};
unsigned char set_time_digits[] = {1,2,0,0};
unsigned char set_alarm_digits[] = {1,2,0,0};

unsigned char keypad_pos = 0;


unsigned char debounce_timer = 40;

unsigned char last_key_pressed = -1;

unsigned char alarm_notification = FALSE;



int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  uduino_init();
  gpio_init();
  led_init();
  switch_init();
  button_init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  /* USER CODE BEGIN 2 */
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

#define INPUT_TEST FALSE
#define LED_TEST TRUE
#define SSD_TEST FALSE
#define KEY_TEST FALSE
#define LCD_TEST FALSE
#define LAB2 FALSE
	// lcd_test_flag = 0;
	  /* USER CODE END 2 */
  while(1){

    led_set(0,button_read('c'));
    led_set(1,button_read('r'));
    led_set(2,button_read('l'));
    led_set(3,button_read('u'));
    led_set(4,button_read('d'));

	  //led test
      for(int i = 0; i < 8; i++){
      //  led_set(i,switch_read(i));
      }
    }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}


void setSSDDigit(char pos, char a, char b, char c, char d, char e, char f, char g){
	switch(pos){
	case 0:
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_4,1);
		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_2,0);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_3,0);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,0);
		break;
	case 1:
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_4,0);
		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_3,0);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,0);
		break;
	case 2:
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_4,0);
		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_2,0);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_3,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,0);
		break;
	case 3:
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_4,0);
		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_2,0);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_3,0);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,1);
	break;
	}

	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_2,a);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_0,b);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_5,c);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_7,d);
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_3,e);
	HAL_GPIO_WritePin(GPIOG,GPIO_PIN_3,f);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_4,g);
}

void setSSD(char pos, char digit){
	switch(digit){
	case 0:
		setSSDDigit(pos,0,0,0,0,0,0,1);
	break;
	case 1:
		setSSDDigit(pos,1,0,0,1,1,1,1);
		break;
	case 2:
		setSSDDigit(pos,0,0,1,0,0,1,0);
		break;
	case 3:
		setSSDDigit(pos,0,0,0,0,1,1,0);
		break;
	case 4:
		setSSDDigit(pos,1,0,0,1,1,0,0);
		break;
	case 5:
		setSSDDigit(pos,0,1,0,0,1,0,0);
		break;
	case 6:
		setSSDDigit(pos,0,1,0,0,0,0,0);
		break;
	case 7:
		setSSDDigit(pos,0,0,0,1,1,1,1);
		break;
	case 8:
		setSSDDigit(pos,0,0,0,0,0,0,0);
		break;
	case 9:
		setSSDDigit(pos,0,0,0,1,1,0,0);
		break;
	case 10:
		setSSDDigit(pos,1,1,1,1,1,1,1);
		break;
	}
}

void setLED(char pos, char value){
	switch (pos){
	case 0:
		HAL_GPIO_WritePin(GPIOF,GPIO_PIN_0,value);
		break;
	case 1:
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_1,value);
		break;
	case 2:
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_0,value);
		break;
	case 3:
		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_0,value);
		break;
	case 4:
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_1,value);
		break;
	case 5:
		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_9,value);
		break;
	case 6:
		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_12,value);
		break;
	case 7:
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_9,value);
		break;
	}
}

void setRow(char row){
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_7,1);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_12,1);
	HAL_GPIO_WritePin(GPIOF,GPIO_PIN_10,0);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_13,0);


	switch(row){
	case 0:
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_11,1);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_10,0);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_12,0);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_14,0);
		break;
	case 1:
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_11,0);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_10,1);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_12,0);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_14,0);
		break;
	case 2:
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_11,0);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_10,0);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_12,1);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_14,0);
		break;
	case 3:
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_11,0);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_10,0);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_12,0);
		HAL_GPIO_WritePin(GPIOE,GPIO_PIN_14,1);
		break;
	}
}
char readKey(char key){
	switch(key){
	case 1:
		setRow(0);
		return HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_14);
		break;
	case 2:
		setRow(0);
		return HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_15);
		break;
	case 3:
		setRow(0);
		return HAL_GPIO_ReadPin(GPIOF,GPIO_PIN_14);
		break;
	case 10:
		setRow(0);
		return HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_9);
		break;
	case 4:
		setRow(1);
		return HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_14);
		break;
	case 5:
		setRow(1);
		return HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_15);
		break;
	case 6:
		setRow(1);
		return HAL_GPIO_ReadPin(GPIOF,GPIO_PIN_14);
		break;
	case 11:
		setRow(1);
		return HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_9);
		break;
	case 7:
		setRow(2);
		return HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_14);
		break;
	case 8:
		setRow(2);
		return HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_15);
		break;
	case 9:
		setRow(2);
		return HAL_GPIO_ReadPin(GPIOF,GPIO_PIN_14);
		break;
	case 12:
		setRow(2);
		return HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_9);
		break;
	case 0:
		setRow(3);
		return HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_14);
		break;
	case 15:
		setRow(3);
		return HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_15);
		break;
	case 14:
		setRow(3);
		return HAL_GPIO_ReadPin(GPIOF,GPIO_PIN_14);
		break;
	case 13:
		setRow(3);
		return HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_9);
		break;
	}

	return -1;
}


char readKeyDebounced(char key){
	char key_pressed = readKey(key);
	if(debounce_timer <= 0 && key_pressed){
		debounce_timer = 100;
		last_key_pressed = key;
		return 1;
	}else{
		return 0;
	}
}

void LCD_Clear() {

	// Chip select to enable LCD
	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_5, GPIO_PIN_RESET);
	HAL_Delay(1);

	// Transmit command
	uint8_t LCD_CMD = 0x01;
	HAL_SPI_Transmit(&hspi1, (uint8_t*) (&LCD_CMD), 1, 100);
	HAL_Delay(1);

	// Chip select to disable LCD
	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_5, GPIO_PIN_SET);

}
void LCD_Write(const uint8_t addr, const char *text, const int count) {

	// Chip Select to enable LCD
	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_5, GPIO_PIN_RESET);
	HAL_Delay(1);

	const char addr_cmd = 0x80 | addr;
	HAL_SPI_Transmit(&hspi1, (uint8_t*) &addr_cmd, 1, 100);
	HAL_Delay(1);

	// Register Select to write to Text Ram in LCD
	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_6, GPIO_PIN_SET);
	HAL_Delay(1);

	// Transmit Data
	for (int z = 0; z < count; z++) {
		HAL_SPI_Transmit(&hspi1, (uint8_t*) (text + z), 1, 100);
		HAL_Delay(1);
	}

	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_6, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_5, GPIO_PIN_SET);

}

void LCD_Init() {

	const uint8_t LCD_INIT_SEQUENCE[] = { 0x38, 0x0c, 0x01, 0x06 };

	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_6, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_5, GPIO_PIN_RESET);
	HAL_Delay(1);

	for (int z = 0; z < sizeof(LCD_INIT_SEQUENCE); z++) {
		HAL_SPI_Transmit(&hspi1, (uint8_t*) (LCD_INIT_SEQUENCE + z), 1, 100);
		HAL_Delay(1);
	}

	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_5, GPIO_PIN_SET);

}
