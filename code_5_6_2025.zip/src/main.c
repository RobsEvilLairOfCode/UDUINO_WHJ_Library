/* USER CODE BEGIN Header */
#include "main.h"
#include <stdio.h>
#include "string.h"



#define FALSE 0
#define TRUE 1

/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */

#include <math.h>


SPI_HandleTypeDef hspi1;

#define SAMPLES 64
#define SAMPLE_RATE 8000  // Hz (adjust timer period to match this)
#define V_CENTER 3100
#define V_AMPLITUDE 1000
#define PI 3.1415

int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  uduino_init();
  gpio_init();
  led_init();
  switch_init();
  button_init();
  ssd_init();
  //ssd_write(1,2,3,4);
  //ssd_set_anode(1);
  //ssd_set_digit_number(2,1);

  //dac_init();
  //lcd_init();
  //lcd_send_string("Hello David!");

  int sine_wave[64];

  for (int i = 0; i < SAMPLES; i++) {
      float angle = (2.0f * PI * i) / SAMPLES;
      float sine = sin(angle);
      sine_wave[i] = (uint32_t)(3100 + 1000 * sine);
  }

 //for(int i = 0; i < SAMPLES; i++){
 // if(i%10 < 5){
 //   sine_wave[i] = 4000;
 // }else{
 //   sine_wave[i] = 0;
 // }
// }

  //timer_16_init(0,50000 - 1);
  //timer_16_set_duty_cycle(1000 - 1);
  //timer_16_start();

  //timer_17_init(0,50000-1);
  //timer_17_set_duty_cycle(2000-1);
  //timer_17_start();


  //led_set_group(0b01010101);
  //dac_start(sine_wave,SAMPLES);
  //dac_set_period(1);
  //gpio_init(PORT_A,4,FALSE);
  //gpio_set_pin(PORT_A,4,TRUE);
  while(1){
    led_set(0,button_read('r'));
    led_set(1,button_read('l'));
    led_set(2,button_read('u'));
    led_set(3,button_read('d'));
    led_set(4,button_read('c'));
  }
}







