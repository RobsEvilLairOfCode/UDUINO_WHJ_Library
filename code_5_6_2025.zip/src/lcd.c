#include "lcd.h"
#include "led.h"

/*
void lcd_init(){
    delay_ms(100);
    led_set(2,1);
    lcd_write_nibble(0x30,0);
    
    delay_ms(30);
    lcd_write_nibble(0x30,0);
    delay_ms(10);
    lcd_write_nibble(0x30,0);
    delay_ms(10);
    lcd_write_nibble(0x20,0);
    
    lcd_send_cmd(0x28);
    lcd_send_cmd(0x10);
    lcd_send_cmd(0x0F);
    lcd_send_cmd(0x06);
}
*/

void lcd_init(void)
{
    MX_I2C3_Init();
    lcd_delay(50); // Wait for LCD to power up
    led_set(2,1);
    // Initialization sequence
    lcd_write_nibble(0x30, 0x00);
    led_set(3,1);
    lcd_delay(50);
    lcd_write_nibble(0x30, 0x00);
    lcd_delay(50);
    lcd_write_nibble(0x30, 0x00);
    lcd_delay(50);
    lcd_write_nibble(0x20, 0x00); // Set to 4-bit mode
    lcd_delay(50);

    

    lcd_send_cmd(0x28); // 4-bit, 2 line, 5x8 dots
    lcd_send_cmd(0x10); // Display off
    lcd_send_cmd(0x0F); // Clear display
    lcd_delay(50);
    lcd_send_cmd(0x06); // Entry mode
    lcd_send_cmd(0x0C); // Display on, cursor off, blink off
}


void lcd_write_nibble(uint8_t nibble, uint8_t control)
{
    uint8_t data = (nibble & 0xF0) | control | LCD_BACKLIGHT;
    uint8_t data_e = data | LCD_ENABLE;
    led_set(2,1);
    HAL_I2C_Master_Transmit(&hi2c3, LCD_ADDR, &data_e, 1, HAL_MAX_DELAY);
    led_set(3,1);
    HAL_Delay(1);
    HAL_I2C_Master_Transmit(&hi2c3, LCD_ADDR, &data, 1, HAL_MAX_DELAY);
    led_set(4,1);
    HAL_Delay(1);
}

void lcd_send_internal(uint8_t data, uint8_t mode)
{
    uint8_t high_nibble = data & 0xF0;
    uint8_t low_nibble = (data << 4) & 0xF0;

    lcd_write_nibble(high_nibble, mode);
    lcd_write_nibble(low_nibble, mode);
}

void lcd_send_cmd(uint8_t cmd)
{
    lcd_send_internal(cmd, 0x00);
}

void lcd_send_data(uint8_t data)
{
    lcd_send_internal(data, LCD_RS);
}

void lcd_send_string(char *str)
{
    while (*str)
    {
        lcd_send_data((uint8_t)(*str));
        str++;
    }
}


void lcd_delay(uint32_t ms) {
    HAL_Delay(ms);
}


void HAL_I2C_MspInit(I2C_HandleTypeDef* hi2c)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};
  if(hi2c->Instance==I2C3)
  {
    /* USER CODE BEGIN I2C3_MspInit 0 */

    /* USER CODE END I2C3_MspInit 0 */

  /** Initializes the peripherals clock
  */
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C3;
    PeriphClkInit.I2c3ClockSelection = RCC_I2C3CLKSOURCE_PCLK1;
    HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit);
    //__HAL_RCC_GPIOG_CLK_ENABLE();
    HAL_PWREx_EnableVddIO2();
    /**I2C3 GPIO Configuration
    PG7     ------> I2C3_SCL
    PG8     ------> I2C3_SDA
    */
    GPIO_InitStruct.Pin = GPIO_PIN_7|GPIO_PIN_8;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF4_I2C3;
    HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

    /* Peripheral clock enable */
    __HAL_RCC_I2C3_CLK_ENABLE();
    /* USER CODE BEGIN I2C3_MspInit 1 */

    /* USER CODE END I2C3_MspInit 1 */

  }

}

void MX_I2C3_Init(void)
{

  /* USER CODE BEGIN I2C3_Init 0 */

  /* USER CODE END I2C3_Init 0 */

  /* USER CODE BEGIN I2C3_Init 1 */

  /* USER CODE END I2C3_Init 1 */
  hi2c3.Instance = I2C3;
  hi2c3.Init.Timing = 0x00100D14;
  hi2c3.Init.OwnAddress1 = 0;
  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c3.Init.OwnAddress2 = 0;
  hi2c3.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  HAL_I2C_Init(&hi2c3);

  /** Configure Analogue filter
  */
  HAL_I2CEx_ConfigAnalogFilter(&hi2c3, I2C_ANALOGFILTER_ENABLE);

  /** Configure Digital filter
  */
  HAL_I2CEx_ConfigDigitalFilter(&hi2c3, 0);
  /* USER CODE BEGIN I2C3_Init 2 */

  /* USER CODE END I2C3_Init 2 */

}

/**
  * @brief I2C MSP De-Initialization
  * This function freeze the hardware resources used in this example
  * @param hi2c: I2C handle pointer
  * @retval None
  */
void HAL_I2C_MspDeInit(I2C_HandleTypeDef* hi2c)
{
  if(hi2c->Instance==I2C3)
  {
    /* USER CODE BEGIN I2C3_MspDeInit 0 */

    /* USER CODE END I2C3_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_I2C3_CLK_DISABLE();

    /**I2C3 GPIO Configuration
    PG7     ------> I2C3_SCL
    PG8     ------> I2C3_SDA
    */
    HAL_GPIO_DeInit(GPIOG, GPIO_PIN_7);

    HAL_GPIO_DeInit(GPIOG, GPIO_PIN_8);

    /* USER CODE BEGIN I2C3_MspDeInit 1 */

    /* USER CODE END I2C3_MspDeInit 1 */
  }

}